#!/bin/sh
\rm -f *.log
\rm -f *.tcf
\rm -f *.rbt
\rm -f *.ncd
\rm -f *.ngd
\rm -f *.ngc
\rm -f *.ngm
\rm -f *.ptwx
\rm -f *.ngo
\rm -f netlist.lst
\rm -f *.lso
\rm -f *.ise
\rm -f *.twr
\rm -f *.xrpt
\rm -rf xlnx_auto_0_xdb
\rm -rf xst
\rm -rf _xmsgs

\rm -f all.xdc
\rm -f *.pad
\rm -f *.bgn
\rm -f *.bld
\rm -f *.drc
\rm -f *.mrp
\rm -f *.par
\rm -f *.pcf
\rm -f *.xpi
\rm -f *_pad.csv
\rm -f *_pad.txt

\rm -f *.unroutes
\rm -f *_usage.xml
\rm -f *_summary.xml
\rm -f *.map

\rm -f  impact_impact.xwbt  impact.xsl webtalk.log

\rm -f  par_usage_statistics.html
\rm -f  *.xwbt
\rm -f  webtalk.log
\rm -f  usage_statistics_webtalk.html
\rm -f  xilinx_device_details.xml

/bin/rm -f  fpga_ila.bit
/bin/rm -f  fpga_ila.ltx
/bin/rm -fr project_1
/bin/rm -f  target.xdc
/bin/rm -f  vivado_*.backup.jou
/bin/rm -f  vivado.jou

