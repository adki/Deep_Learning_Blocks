
'iverilog.cosim' will not work since the design uses Xilinx specific primitives.

