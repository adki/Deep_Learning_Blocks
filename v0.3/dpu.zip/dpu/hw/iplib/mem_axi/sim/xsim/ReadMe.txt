
How to run:

$ make

1. elaboration using 'xelab'
   $ make elab
2. obsoleted - wave-generation embedded
   prepare ADC data file 'adc.txt' using 'dfft.py'
   'adc.txt' containing a comment line and a series of signed float values.
   $ make adc
3. simulation using 'xsim'
   $ make sim
4. duing simulation
   - 'adc.txt': float values of ADC result
   - 'adc_fixed.txt': hex (fixed-point) version of 'adc.txt' to push to FFT core
   - 'fft.txt': float values of FFT result
   - 'fft_fixed.txt': hex (fixed-point) version of 'fft.txt' got from FFT core
5. view signal wave
   $ make wave
6. view plot using 'adc.txt' and 'fft.txt'
   $ make plot


How to add signals.

refer to 'num_sin' in '../../bench/verilog/tester.v'.
